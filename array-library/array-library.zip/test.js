import {ArrayHelper} from './arrayLibrary.js';

let testArray = ["Item1", "Item2", "Item3"];

alert("Take command result " + ArrayHelper.take(testArray, 2));

alert("Skip command result " + ArrayHelper.skip(testArray, 2));

function mapFunction(item) {
    return "modified " + item;
}

alert("Map command result " + ArrayHelper.map(testArray, mapFunction));

function reduceFunction(result, item) {
    return result + item + ", ";
}

alert("Reduce command result " + ArrayHelper.reduce(testArray, reduceFunction, "Sequence of elements: "));

function filterFunction(item) {
    return item == "Item2";
}

alert("Filter command result " + ArrayHelper.filter(testArray, filterFunction));

function forEachFunction(item) {
    item += "!";
}

alert("ForEach command result " + ArrayHelper.foreach(testArray, foreachFunction));

